import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class Workout {
  String exercise;
  int sets;
  int reps;

  Workout(this.exercise, this.sets, this.reps);
}

class WorkoutPlan {
  String name;
  List<Workout> exercises;

  WorkoutPlan(this.name, this.exercises);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Fitness Tracker'),
            bottom: TabBar(
              tabs: [
                Tab(text: 'Input Workout'),
                Tab(text: 'Explore Plans'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              WorkoutInputPage(),
              WorkoutPlansPage(),
            ],
          ),
        ),
      ),
    );
  }
}

class WorkoutInputPage extends StatefulWidget {
  @override
  _WorkoutInputPageState createState() => _WorkoutInputPageState();
}
class _WorkoutInputPageState extends State<WorkoutInputPage> {
  String selectedExercise = 'Push-ups';
  int sets = 3;
  int reps = 10;
  List<Workout> workoutList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Input Workout'),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/blue.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButton<String>(
                value: selectedExercise,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedExercise = newValue!;
                  });
                },
                items: ['Push-ups', 'Squats', 'Plank']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 16.0),
              Text(
                'Sets:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Row(
                children: [
                  Radio(
                    value: 1,
                    groupValue: sets,
                    onChanged: (int? value) {
                      setState(() {
                        sets = value!;
                      });
                    },
                  ),
                  Text('1'),
                  Radio(
                    value: 2,
                    groupValue: sets,
                    onChanged: (int? value) {
                      setState(() {
                        sets = value!;
                      });
                    },
                  ),
                  Text('2'),
                  Radio(
                    value: 3,
                    groupValue: sets,
                    onChanged: (int? value) {
                      setState(() {
                        sets = value!;
                      });
                    },
                  ),
                  Text('3'),
                  Radio(
                    value: 4,
                    groupValue: sets,
                    onChanged: (int? value) {
                      setState(() {
                        sets = value!;
                      });
                    },
                  ),
                  Text('4'),
                  Radio(
                    value: 5,
                    groupValue: sets,
                    onChanged: (int? value) {
                      setState(() {
                        sets = value!;
                      });
                    },
                  ),
                  Text('5'),
                  // Add more radio buttons as needed
                ],
              ),
              Text(
                'Reps:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Row(
                children: [
                  Radio(
                    value: 5,
                    groupValue: reps,
                    onChanged: (int? value) {
                      setState(() {
                        reps = value!;
                      });
                    },
                  ),
                  Text('5'),
                  Radio(
                    value: 10,
                    groupValue: reps,
                    onChanged: (int? value) {
                      setState(() {
                        reps = value!;
                      });
                    },
                  ),
                  Text('10'),
                  Radio(
                    value: 15,
                    groupValue: reps,
                    onChanged: (int? value) {
                      setState(() {
                        reps = value!;
                      });
                    },
                  ),
                  Text('15'),
                  Radio(
                    value: 20,
                    groupValue: reps,
                    onChanged: (int? value) {
                      setState(() {
                        reps = value!;
                      });
                    },
                  ),
                  Text('20'),
                  // Add more radio buttons as needed
                ],
              ),
              SizedBox(height: 16.0),
              ElevatedButton.icon(
                onPressed: () {
                  Workout workout = Workout(selectedExercise, sets, reps);
                  workoutList.add(workout);
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.redAccent,
                  onPrimary: Colors.white,
                ),
                icon: Icon(Icons.add),
                label: Text('Add Workout'),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => WorkoutListPage(workoutList),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.blueGrey,
                  onPrimary: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.list),
                    SizedBox(width: 8.0),
                    Text('View Workouts'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class WorkoutPlansPage extends StatelessWidget {
  final List<WorkoutPlan> beginnerPlans = [
    WorkoutPlan(
      'Beginner Full Body',
      [
        Workout('Push-ups', 3, 5),
        Workout('Squats', 3, 10),
        Workout('Plank', 3, 15),
      ],
    ),
  ];

  final List<WorkoutPlan> intermediatePlans = [
    WorkoutPlan(
      'Intermediate Full Body',
      [
        Workout('Push-ups', 4, 5),
        Workout('Squats', 4, 10),
        Workout('Plank', 4, 15),
      ],
    ),
  ];

  final List<WorkoutPlan> expertPlans = [
    WorkoutPlan(
      'Expert Full Body',
      [
        Workout('Push-ups', 5, 5),
        Workout('Squats', 5, 10),
        Workout('Plank', 5, 15),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Explore Plans'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Beginner Plans
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/beginner.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Beginner Plans',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: beginnerPlans.length,
              itemBuilder: (context, index) {
                return buildWorkoutPlanCard(context, beginnerPlans[index]);
              },
            ),
          ),
          SizedBox(height: 16.0),

          // Intermediate Plans
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/intermediate.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Intermediate Plans',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: intermediatePlans.length,
              itemBuilder: (context, index) {
                return buildWorkoutPlanCard(context, intermediatePlans[index]);
              },
            ),
          ),
          SizedBox(height: 16.0),

          // Expert Plans
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/expert.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Expert Plans',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: expertPlans.length,
              itemBuilder: (context, index) {
                return buildWorkoutPlanCard(context, expertPlans[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildWorkoutPlanCard(BuildContext context, WorkoutPlan workoutPlan) {
    return Card(
      elevation: 5.0,
      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: ListTile(
        title: Text(
          workoutPlan.name,
          style: TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WorkoutPlanDetailsPage(workoutPlan),
            ),
          );
        },
      ),
    );
  }
}

class WorkoutPlanDetailsPage extends StatelessWidget {
  final WorkoutPlan workoutPlan;

  WorkoutPlanDetailsPage(this.workoutPlan);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(workoutPlan.name),
      ),
      body: ListView.builder(
        itemCount: workoutPlan.exercises.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 5.0,
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              title: Text(
                workoutPlan.exercises[index].exercise,
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              subtitle: Text(
                'Sets: ${workoutPlan.exercises[index].sets}, Reps: ${workoutPlan.exercises[index].reps}',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}


class WorkoutListPage extends StatelessWidget {
  final List<Workout> workoutList;

  WorkoutListPage(this.workoutList);

  // Map workout names to their respective image paths
  final Map<String, String> workoutImages = {
    'Plank': 'assets/plank.jpg',
    'Push-ups': 'assets/push.jpg',
    'Squats': 'assets/squats.jpg',
  };


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workout List'),
      ),
      body: ListView.builder(
        itemCount: workoutList.length,
        itemBuilder: (context, index) {
          final workout = workoutList[index];
          final imagePath = workoutImages[workout.exercise];

          return Card(
            elevation: 5.0,
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              leading: Image.asset(
                imagePath ?? 'assets/default_image.jpg', // Use a default image if not found
                height: 48,
                width: 48,
                fit: BoxFit.cover,
              ),
              title: Text(
                workout.exercise,
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              subtitle: Text(
                'Sets: ${workout.sets}, Reps: ${workout.reps}',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
