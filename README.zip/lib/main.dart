import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class Workout {
  String exercise;
  int sets;
  int reps;

  Workout(this.exercise, this.sets, this.reps);
}

class WorkoutPlan {
  String name;
  List<Workout> exercises;

  WorkoutPlan(this.name, this.exercises);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Fitness Tracker'),
            bottom: TabBar(
              tabs: [
                Tab(text: 'Input Workout'),
                Tab(text: 'Explore Plans'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              WorkoutInputPage(),
              WorkoutPlansPage(),
            ],
          ),
        ),
      ),
    );
  }
}

class WorkoutInputPage extends StatefulWidget {
  @override
  _WorkoutInputPageState createState() => _WorkoutInputPageState();
}

class _WorkoutInputPageState extends State<WorkoutInputPage> {
  String selectedExercise = 'Push-ups';
  int sets = 3;
  int reps = 10;
  List<Workout> workoutList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Input Workout'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButton<String>(
              value: selectedExercise,
              onChanged: (String? newValue) {
                setState(() {
                  selectedExercise = newValue!;
                });
              },
              items: ['Push-ups', 'Squats', 'Plank']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            Text(
              'Sets: $sets',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            Slider(
              value: sets.toDouble(),
              min: 1,
              max: 5,
              onChanged: (value) {
                setState(() {
                  sets = value.toInt();
                });
              },
            ),
            Text(
              'Reps: $reps',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            Slider(
              value: reps.toDouble(),
              min: 5,
              max: 20,
              onChanged: (value) {
                setState(() {
                  reps = value.toInt();
                });
              },
            ),
            SizedBox(height: 16.0),
            ElevatedButton.icon(
              onPressed: () {
                Workout workout = Workout(selectedExercise, sets, reps);
                workoutList.add(workout);
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.redAccent,
                onPrimary: Colors.white,
              ),
              icon: Icon(Icons.add),
              label: Text('Add Workout'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WorkoutListPage(workoutList),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blueGrey,
                onPrimary: Colors.white,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.list),
                  SizedBox(width: 8.0),
                  Text('View Workouts'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WorkoutPlansPage extends StatelessWidget {
  final List<WorkoutPlan> workoutPlans = [
    WorkoutPlan(
      'Beginner Full Body',
      [
        Workout('Push-ups', 3, 10),
        Workout('Squats', 3, 12),
        Workout('Plank', 3, 30),
      ],
    ),
    // Add more workout plans as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Explore Plans'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Explore Workout Plans',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: ListView.builder(
                itemCount: workoutPlans.length,
                itemBuilder: (context, index) {
                  return Card(
                    elevation: 5.0,
                    margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    child: ListTile(
                      title: Text(
                        workoutPlans[index].name,
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => WorkoutPlanDetailsPage(workoutPlans[index]),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WorkoutPlanDetailsPage extends StatelessWidget {
  final WorkoutPlan workoutPlan;

  WorkoutPlanDetailsPage(this.workoutPlan);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(workoutPlan.name),
      ),
      body: ListView.builder(
        itemCount: workoutPlan.exercises.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 5.0,
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              title: Text(
                workoutPlan.exercises[index].exercise,
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              subtitle: Text(
                'Sets: ${workoutPlan.exercises[index].sets}, Reps: ${workoutPlan.exercises[index].reps}',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}


class WorkoutListPage extends StatelessWidget {
  final List<Workout> workoutList;

  WorkoutListPage(this.workoutList);

  // Map workout names to their respective image paths
  final Map<String, String> workoutImages = {
    'Plank': 'assets/plank.jpg',
    'Push-ups': 'assets/push.jpg',
    'Squats': 'assets/squats.jpg',
  };


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workout List'),
      ),
      body: ListView.builder(
        itemCount: workoutList.length,
        itemBuilder: (context, index) {
          final workout = workoutList[index];
          final imagePath = workoutImages[workout.exercise];

          return Card(
            elevation: 5.0,
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListTile(
              leading: Image.asset(
                imagePath ?? 'assets/default_image.jpg', // Use a default image if not found
                height: 48,
                width: 48,
                fit: BoxFit.cover,
              ),
              title: Text(
                workout.exercise,
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              subtitle: Text(
                'Sets: ${workout.sets}, Reps: ${workout.reps}',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
